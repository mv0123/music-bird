import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-CQ2F7NCU.js";
import "./chunk-M3A3ZGYR.js";
import "./chunk-EY5DCSOL.js";
import "./chunk-WDLYRPUI.js";
import "./chunk-MD2JTI2T.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
